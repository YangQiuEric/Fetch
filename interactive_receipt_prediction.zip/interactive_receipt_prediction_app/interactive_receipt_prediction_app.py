from flask import Flask, request, render_template
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.preprocessing import MinMaxScaler
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from io import BytesIO
import base64

# Initialize Flask app
app = Flask(__name__)

# Define the TimeSeriesNN model
class TimeSeriesNN(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim=1):
        super(TimeSeriesNN, self).__init__()
        self.lstm = nn.LSTM(input_dim, hidden_dim, batch_first=True)
        self.fc = nn.Linear(hidden_dim, output_dim)

    def forward(self, x):
        h_0 = torch.zeros(1, x.size(0), 50)  # Initial hidden state
        c_0 = torch.zeros(1, x.size(0), 50)  # Initial cell state
        out, _ = self.lstm(x, (h_0, c_0))
        out = self.fc(out[:, -1, :])
        return out
# Define training function
def train_model(model, criterion, optimizer, x_train, y_train, num_epochs=100):
    train_loss = []
    for epoch in range(num_epochs):
        model.train()
        optimizer.zero_grad()
        outputs = model(x_train)
        loss = criterion(outputs, y_train)
        loss.backward()
        optimizer.step()
        train_loss.append(loss.item())
    return train_loss

@app.route('/', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        # Read uploaded CSV file
        uploaded_file = request.files['file']
        df = pd.read_csv(uploaded_file)
        df['# Date'] = pd.to_datetime(df['# Date'])
        df = df.sort_values(by=['# Date'])

        # Preprocessing for TimeSeriesNN
        scaler = MinMaxScaler()
        scaled_data = scaler.fit_transform(df[['Receipt_Count']])
        seq_length = 10
        X, y = [], []

        for i in range(len(scaled_data) - seq_length):
            seq = scaled_data[i:i + seq_length]
            label = scaled_data[i + seq_length]
            X.append(seq)
            y.append(label)

        # Convert to PyTorch tensors
        X = torch.tensor(X, dtype=torch.float32)
        y = torch.tensor(y, dtype=torch.float32)

        # Initialize and train the model
        model = TimeSeriesNN(1, 50)
        criterion = nn.MSELoss()
        optimizer = optim.Adam(model.parameters(), lr=0.01)
        train_loss = train_model(model, criterion, optimizer, X, y)

        # Create data for 2022
        date_range_2022 = pd.date_range(start='2022-01-01', end='2022-12-31', freq='D')
        last_seq = scaled_data[-seq_length:]  # Start with the last `seq_length` entries from the scaled_data
        y_2022 = []

        for i in range(len(date_range_2022)):
            new_seq = torch.tensor(last_seq.reshape(1, seq_length, 1), dtype=torch.float32)
            prediction = model(new_seq).detach().numpy()  # Make prediction
            y_2022.append(prediction[0][0])  # Store prediction
            
            # Update the last_seq for next prediction
            last_seq = np.roll(last_seq, shift=-1)
            last_seq[-1] = prediction  # Replace the placeholder with the new prediction

        y_2022 = np.array(y_2022)
        # print("y_2022",y_2022)

        # Generate loss plot
        plt.figure(figsize=(15, 6))
        plt.subplot(1, 2, 1)
        plt.plot(train_loss, label='Training Loss')
        plt.xlabel('Epoch')
        plt.ylabel('Loss')
        plt.title('Training Loss')

        # Generate prediction plot for 2022
        plt.subplot(1, 2, 2)
        plt.plot(range(len(y_2022)), y_2022, label='2022 Prediction')
        plt.xlabel('Date Index')
        plt.ylabel('Prediction')
        plt.title('2022 Prediction')

        # Create list of month-day strings for the 12 months of 2022
        month_days = [f"{str(month).zfill(2)}-01" for month in range(1, 13)]

        # Calculate positions for the tick labels (assuming y_2022 contains one value per day)
        tick_positions = [i for i in range(0, len(y_2022), len(y_2022)//12)][:12]

        # Set tick positions and labels
        plt.xticks(tick_positions, month_days)
        # Save the plot to a BytesIO object
        img = BytesIO()
        plt.savefig(img, format='png')
        img.seek(0)
        plot_url = base64.b64encode(img.getvalue()).decode()

        return render_template('index.html', plot_url=plot_url)

    return render_template('index.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug=True)
